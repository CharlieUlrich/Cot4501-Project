## Overview 

This module provides support for reading and writing ZIP archives in Julia.

[![Build Status](https://travis-ci.org/fhs/ZipFile.jl.png)](https://travis-ci.org/fhs/ZipFile.jl)

## Installation

Install via the Julia package manager, `Pkg.add("ZipFile")`.
